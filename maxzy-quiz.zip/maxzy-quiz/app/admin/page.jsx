'use client';
import { useState, useEffect } from 'react';
const api = (b) => fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(async (r) => ({ ok: r.ok, ...(await r.json()) }));
export default function Admin() {
  const [d, setD] = useState(null), [pw, setPw] = useState(''), [m, setM] = useState('');
  const load = async () => { const r = await fetch('/api/admin'); if (r.ok) setD(await r.json()); };
  useEffect(() => { load(); }, []);
  const run = async (b, ask) => { if (ask && !confirm(ask)) return; const r = await api(b); if (r.ok) { if (r.questions) setD(r); setM('บันทึกแล้ว ✓'); } else setM(r.error || 'ผิดพลาด'); };
  if (!d) return (<main className="max-w-sm mx-auto p-6 pt-20 space-y-3"><h1 className="text-2xl font-bold neon">Admin</h1>
    <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="รหัสผ่าน" className="w-full rounded-xl bg-black/50 border border-purple-700 p-3" />
    <button className="btn go" onClick={async () => { const r = await api({ action: 'login', password: pw }); if (r.ok) load(); else setM(r.error); }}>เข้าสู่ระบบ</button><p className="text-rose-400">{m}</p></main>);
  const upd = (id, f, v) => setD({ ...d, questions: d.questions.map((q) => (q.id === id ? { ...q, [f]: v } : q)) });
  const inp = 'w-full rounded-lg bg-black/50 border border-purple-800 p-2 text-sm';
  return (<main className="max-w-2xl mx-auto p-4 space-y-4">
    <div className="flex flex-wrap gap-2 items-center"><h1 className="text-2xl font-bold neon flex-1">Admin 💜</h1>
      <button className="btn !w-auto" onClick={() => run({ action: 'toggle', open: !d.open })}>{d.open ? '🟢 เกมเปิด (กดปิด)' : '🔴 เกมปิด (กดเปิด)'}</button>
      <button className="btn !w-auto" onClick={() => run({ action: 'reset' }, 'ลบคะแนนทั้งหมด?')}>รีเซ็ตคะแนน</button>
      <button className="btn !w-auto" onClick={async () => { await api({ action: 'logout' }); setD(null); }}>ออก</button></div>
    <p className="text-sm text-emerald-300">{m}</p>
    <h2 className="font-bold">คำถาม ({d.questions.length})</h2>
    {d.questions.map((q) => (<div key={q.id || q.tmp} className="card p-3 space-y-2">
      <div className="flex gap-2"><input type="number" className={inp + ' !w-16'} value={q.position} onChange={(e) => upd(q.id, 'position', +e.target.value)} /><input className={inp} value={q.text} onChange={(e) => upd(q.id, 'text', e.target.value)} /></div>
      {q.options.map((o, k) => (<label key={k} className="flex gap-2 items-center"><input type="radio" checked={q.correct === k} onChange={() => upd(q.id, 'correct', k)} /><input className={inp} value={o} onChange={(e) => upd(q.id, 'options', q.options.map((x, j) => (j === k ? e.target.value : x)))} /></label>))}
      <div className="flex gap-2"><button className="btn go !py-2" onClick={() => run({ action: 'saveQuestion', q })}>บันทึก</button><button className="btn !py-2 text-center" onClick={() => run({ action: 'deleteQuestion', id: q.id }, 'ลบข้อนี้?')}>ลบ</button></div></div>))}
    <button className="btn text-center" onClick={() => run({ action: 'saveQuestion', q: { text: 'คำถามใหม่', options: ['ก', 'ข', 'ค', 'ง'], correct: 0, position: d.questions.length + 1 } })}>+ เพิ่มคำถาม</button>
    <h2 className="font-bold">ผลคะแนน ({d.results.length})</h2>
    {d.results.map((r) => (<div key={r.id} className="card p-2 flex items-center gap-2 text-sm"><span className="flex-1 truncate">{r.player_name} · {r.score}/{r.total} · {r.status}</span><button className="px-3" onClick={() => run({ action: 'deleteResult', id: r.id }, 'ลบผลนี้?')}>🗑</button></div>))}
  </main>);
}
