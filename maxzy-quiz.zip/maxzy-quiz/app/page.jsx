'use client';
import { useState, useEffect } from 'react';
const L = ['abcd'[0]]; const LET = ['A', 'B', 'C', 'D'];
const TITLES = [[15, 'MAXZY SOULMATE', 'รู้ใจยิ่งกว่าเจ้าตัวอีก! 💜'], [12, 'คนรู้ใจตัวจริง', 'สนิทกันมากสินะเนี่ย!'], [9, 'เพื่อนสนิท', 'รู้จักกันดีอยู่นะ'], [6, 'เพื่อนทั่วไป', 'ยังต้องศึกษาอีกเยอะ 555'], [3, 'คนแปลกหน้า', 'เราเคยคุยกันไหม?'], [0, 'ใครก็ไม่รู้ 555', 'กลับไปทำความรู้จักใหม่ก่อน!']];
const tone = (f, d = 0.18) => { try { const c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator(), g = c.createGain(); o.frequency.value = f; o.connect(g); g.connect(c.destination); g.gain.setValueAtTime(0.1, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + d); o.start(); o.stop(c.currentTime + d); } catch {} };
const post = (b) => fetch('/api/game', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(async (r) => ({ ok: r.ok, ...(await r.json()) }));
const fmt = (ms) => { const s = Math.round(ms / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

export default function Home() {
  const [v, setV] = useState('home'), [name, setName] = useState(''), [qs, setQs] = useState([]), [open, setOpen] = useState(true);
  const [i, setI] = useState(0), [gid, setGid] = useState(null), [pick, setPick] = useState(null), [fb, setFb] = useState(null), [score, setScore] = useState(0);
  const [lb, setLb] = useState([]), [mute, setMute] = useState(false), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), [copied, setCopied] = useState(false);
  useEffect(() => { fetch('/api/questions').then((r) => r.json()).then((d) => { setQs(d.questions); setOpen(d.open); }); }, []);
  const snd = (f) => !mute && tone(f);
  const start = async () => {
    if (!name.trim()) return setMsg('กรอกชื่อก่อนนะ');
    setBusy(true); setMsg('');
    const r = await post({ action: 'start', name }); setBusy(false);
    if (!r.ok) return setMsg(r.error);
    const d = await (await fetch('/api/questions')).json(); setQs(d.questions);
    setGid(r.gameId); setI(0); setScore(0); setPick(null); setFb(null); setV('play');
  };
  const answer = async (c) => {
    if (pick !== null || busy) return; setPick(c); setBusy(true);
    const r = await post({ action: 'answer', gameId: gid, questionId: qs[i].id, choice: c }); setBusy(false);
    if (!r.ok) { setPick(null); return setMsg(r.error); }
    setFb(r); if (r.isRight) { setScore((s) => s + 1); snd(880); } else snd(180);
  };
  const next = async () => {
    if (i + 1 < qs.length) { setI(i + 1); setPick(null); setFb(null); return; }
    setBusy(true); const r = await post({ action: 'finish', gameId: gid }); setBusy(false);
    if (r.ok) { setScore(r.score); setV('result'); snd(1000); }
  };
  const loadLb = async () => { setLb((await (await fetch('/api/leaderboard')).json()).rows); setV('lb'); };
  const total = qs.length || 15, t = TITLES.find((x) => score >= x[0]) || TITLES[5];
  const url = typeof window !== 'undefined' ? location.origin : '';
  const text = `ฉันเล่น MAXZY QUIZ ได้ ${score}/${total} คะแนน!\nฉันรู้จักแม็กซ์ซี่ดีแค่ไหน?\nแล้วคุณล่ะ กล้าทดสอบไหม?`;
  const copy = async () => { try { await navigator.clipboard.writeText(text + '\n' + url); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {} };
  const share = () => (navigator.share ? navigator.share({ text, url }).catch(() => {}) : copy());
  const q = qs[i];
  return (
    <main className="max-w-md mx-auto p-4 pb-10 relative">
      {[...Array(10)].map((_, k) => <span key={k} className="pt" style={{ left: k * 10 + 3 + '%', animationDelay: -k * 1.4 + 's' }} />)}
      <button onClick={() => setMute(!mute)} className="fixed top-3 right-3 z-10 card px-3 py-1 text-sm" aria-label="เสียง">{mute ? '🔇' : '🔊'}</button>
      {v === 'home' && (<div className="text-center pt-10 space-y-5">
        <h1 className="text-5xl font-extrabold neon">MAXZY QUIZ 💜</h1>
        <p className="text-xl text-pink-300">รู้จักแม็กซ์ซี่ดีแค่ไหน?</p>
        <p className="text-sm text-purple-200">คิดว่ารู้จักเราดีจริงเหรอ? มาพิสูจน์หน่อยสิ 😏<br />อย่าคิดว่ารู้จักเราดี ถ้ายังตอบคำถามพวกนี้ไม่ได้ 555</p>
        <div className="card p-5 space-y-3">
          <input value={name} maxLength={20} onChange={(e) => setName(e.target.value)} placeholder="ชื่อของคุณ" className="w-full rounded-xl bg-black/50 border border-purple-700 p-3 text-center outline-none focus:border-pink-500" />
          {msg && <p className="text-rose-400 text-sm">{msg}</p>}
          {!open && <p className="text-amber-300 text-sm">เกมปิดอยู่ชั่วคราว</p>}
          <button disabled={busy || !open} onClick={start} className="btn go disabled:opacity-50">🎮 เริ่มเล่นเกม</button>
          <button onClick={loadLb} className="btn text-center">🏆 ดูอันดับเพื่อน</button>
        </div>
        <div className="flex justify-around text-sm text-purple-200"><span><b className="block text-2xl text-white">{total}</b>QUESTIONS</span><span><b className="block text-2xl text-white">{total}</b>POINTS</span><span><b className="block text-2xl text-white">1</b>MAXZY</span></div>
      </div>)}
      {v === 'play' && q && (<div className="pt-10 space-y-4">
        <div className="flex justify-between text-sm text-purple-200"><span>QUESTION {i + 1}/{qs.length}</span><span>⭐ {score}</span></div>
        <div className="h-2 rounded bg-purple-950"><div className="h-2 rounded bg-gradient-to-r from-fuchsia-500 to-rose-500 transition-all" style={{ width: ((i + (fb ? 1 : 0)) / qs.length) * 100 + '%' }} /></div>
        <div className="card p-5"><h2 className="text-xl font-bold mb-4">{q.text}</h2>
          <div className="space-y-3">{q.options.map((o, k) => {
            const cls = fb ? (k === fb.correct ? 'ok' : k === pick ? 'bad' : '') : '';
            return <button key={k} disabled={pick !== null} onClick={() => answer(k)} className={`btn ${cls}`}><b className="text-pink-400 mr-2">{LET[k]}</b>{o}</button>;
          })}</div></div>
        {fb && (<div className="card p-4 text-center space-y-3"><p className="font-bold">{fb.isRight ? 'เก่งมาก! รู้ใจแม็กซ์จริงๆ 💜' : 'ผิดจ้าาา ไปทำความรู้จักแม็กซ์ใหม่เลย 555'}</p>
          {!fb.isRight && <p className="text-sm text-emerald-300">เฉลย: {LET[fb.correct]}. {q.options[fb.correct]}</p>}
          <button disabled={busy} onClick={next} className="btn go">{i + 1 < qs.length ? 'ข้อต่อไป' : 'ดูผลคะแนน'}</button></div>)}
        {msg && <p className="text-rose-400 text-sm text-center">{msg}</p>}
      </div>)}
      {v === 'result' && (<div className="pt-10 text-center space-y-4">
        {score >= 9 && [...Array(24)].map((_, k) => <span key={k} className="fall text-2xl" style={{ left: (k * 4.3) % 100 + '%', animationDuration: 3 + (k % 5) + 's' }}>{['💜', '✨', '🎉'][k % 3]}</span>)}
        <p className="text-pink-300">{name}</p>
        <div className="card p-6 space-y-2"><p className="text-7xl font-extrabold neon">{score}<span className="text-2xl text-purple-300">/{total}</span></p>
          <p className="text-lg">{Math.round((score / total) * 100)}% ความรู้ใจ</p>
          <h2 className="text-2xl font-bold text-pink-400">{t[1]}</h2><p>{t[2]}</p></div>
        <button onClick={share} className="btn go">📤 แชร์คะแนน</button>
        <div className="grid grid-cols-3 gap-2 text-sm">
          <button onClick={copy} className="btn text-center">{copied ? 'คัดลอกแล้ว' : 'Copy Link'}</button>
          <a className="btn text-center" target="_blank" rel="noreferrer" href={'https://social-plugins.line.me/lineit/share?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(text)}>LINE</a>
          <a className="btn text-center" target="_blank" rel="noreferrer" href={'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url) + '&quote=' + encodeURIComponent(text)}>Facebook</a></div>
        <button onClick={loadLb} className="btn text-center">🏆 ดูอันดับเพื่อน</button>
        <button onClick={() => setV('home')} className="btn text-center">🔁 เล่นอีกครั้ง</button>
      </div>)}
      {v === 'lb' && (<div className="pt-10 space-y-3">
        <h2 className="text-3xl font-extrabold neon text-center">🏆 อันดับเพื่อน</h2>
        {lb.length === 0 && <p className="text-center text-purple-200">ยังไม่มีใครเล่น ไปเป็นคนแรกเลย</p>}
        {lb.map((r, k) => (<div key={r.id} className={`card p-3 flex items-center gap-3 ${k === 0 ? 'border-yellow-400' : ''}`}>
          <span className="text-2xl w-9 text-center">{['🥇', '🥈', '🥉'][k] || k + 1}</span>
          <div className="flex-1 min-w-0"><p className="font-bold truncate">{k === 0 && '🏆 '}{r.player_name}</p><p className="text-xs text-purple-300">{new Date(r.finished_at).toLocaleDateString('th-TH')} · {fmt(r.play_ms)} นาที</p></div>
          <div className="text-right"><b>{r.score}/{r.total}</b><p className="text-xs text-pink-300">{Math.round((r.score / (r.total || 1)) * 100)}%</p></div></div>))}
        <button onClick={() => setV('home')} className="btn text-center">กลับหน้าแรก</button>
      </div>)}
    </main>
  );
}
