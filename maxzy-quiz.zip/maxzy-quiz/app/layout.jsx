import './globals.css';
export const metadata = { title: 'MAXZY QUIZ 💜', description: 'รู้จักแม็กซ์ซี่ดีแค่ไหน?' };
export const viewport = { width: 'device-width', initialScale: 1 };
export default function L({ children }) {
  return (<html lang="th"><head><link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;700;800&display=swap" rel="stylesheet" /></head><body>{children}</body></html>);
}
