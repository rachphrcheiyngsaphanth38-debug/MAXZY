import { db } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET() {
  const s = db();
  const { data: st } = await s.from('admin_settings').select('value').eq('key', 'game_open').maybeSingle();
  const { data } = await s.from('questions').select('id,text,options').order('position');
  return Response.json({ open: st?.value !== 'false', questions: data || [] });
}
