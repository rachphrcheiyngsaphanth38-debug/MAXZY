import { db } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET() {
  const { data } = await db().from('game_results').select('id,player_name,score,total,finished_at,play_ms')
    .eq('status', 'done').order('score', { ascending: false }).order('play_ms', { ascending: true }).limit(50);
  return Response.json({ rows: data || [] });
}
