import { db } from '@/lib/db';
import { isAdmin, makeToken, passOk } from '@/lib/auth';
export const dynamic = 'force-dynamic';
const no = () => Response.json({ error: 'unauthorized' }, { status: 401 });
async function load() {
  const s = db();
  const [q, r, st] = await Promise.all([
    s.from('questions').select('*').order('position'),
    s.from('game_results').select('id,player_name,score,total,status,finished_at,play_ms').order('score', { ascending: false }).order('play_ms', { ascending: true }),
    s.from('admin_settings').select('value').eq('key', 'game_open').maybeSingle()]);
  return { questions: q.data || [], results: r.data || [], open: st.data?.value !== 'false' };
}
export async function GET() { return isAdmin() ? Response.json(await load()) : no(); }
export async function POST(req) {
  const b = await req.json().catch(() => ({}));
  const s = db();
  if (b.action === 'login') {
    if (!passOk(b.password)) return Response.json({ error: 'รหัสผ่านไม่ถูกต้อง' }, { status: 401 });
    const res = Response.json({ ok: true });
    res.headers.append('Set-Cookie', `adm=${makeToken()}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`);
    return res;
  }
  if (b.action === 'logout') { const r = Response.json({ ok: true }); r.headers.append('Set-Cookie', 'adm=; Path=/; Max-Age=0'); return r; }
  if (!isAdmin()) return no();
  if (b.action === 'saveQuestion') {
    const q = b.q || {};
    const o = Array.isArray(q.options) ? q.options.map((x) => String(x).trim()).slice(0, 4) : [];
    if (!String(q.text || '').trim() || o.length !== 4 || o.some((x) => !x) || ![0, 1, 2, 3].includes(+q.correct)) return Response.json({ error: 'ข้อมูลไม่ครบ' }, { status: 400 });
    const row = { text: q.text.trim(), options: o, correct: +q.correct, position: +q.position || 0 };
    if (q.id) await s.from('questions').update(row).eq('id', q.id); else await s.from('questions').insert(row);
  } else if (b.action === 'deleteQuestion') await s.from('questions').delete().eq('id', b.id);
  else if (b.action === 'deleteResult') await s.from('game_results').delete().eq('id', b.id);
  else if (b.action === 'toggle') await s.from('admin_settings').upsert({ key: 'game_open', value: b.open ? 'true' : 'false' });
  else if (b.action === 'reset') { await s.from('game_results').delete().neq('id', '00000000-0000-0000-0000-000000000000'); await s.from('players').delete().neq('id', '00000000-0000-0000-0000-000000000000'); }
  return Response.json(await load());
}
