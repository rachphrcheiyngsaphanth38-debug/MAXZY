import { db } from '@/lib/db';
export const dynamic = 'force-dynamic';
const err = (m, c = 400) => Response.json({ error: m }, { status: c });
export async function POST(req) {
  let b; try { b = await req.json(); } catch { return err('bad json'); }
  const s = db();
  if (b.action === 'start') {
    const name = String(b.name || '').trim().slice(0, 20);
    if (!name) return err('กรุณากรอกชื่อ');
    const { data: st } = await s.from('admin_settings').select('value').eq('key', 'game_open').maybeSingle();
    if (st?.value === 'false') return err('เกมปิดอยู่ตอนนี้', 403);
    const { count } = await s.from('questions').select('id', { count: 'exact', head: true });
    const { data: p } = await s.from('players').insert({ name }).select('id').single();
    const { data: g, error } = await s.from('game_results').insert({ player_id: p?.id, player_name: name, total: count || 0, answers: {}, status: 'playing' }).select('id').single();
    if (error) return err('เริ่มเกมไม่ได้', 500);
    return Response.json({ gameId: g.id });
  }
  const { data: g } = await s.from('game_results').select('*').eq('id', String(b.gameId || '')).maybeSingle();
  if (!g || g.status !== 'playing') return err('เกมนี้จบแล้วหรือไม่พบ', 404);
  const { data: qs } = await s.from('questions').select('id,correct').order('position');
  if (b.action === 'answer') {
    const next = qs.find((q) => !(q.id in g.answers));
    if (!next || next.id !== b.questionId) return err('ข้ามหรือตอบซ้ำไม่ได้', 409);
    const c = Number(b.choice); if (![0, 1, 2, 3].includes(c)) return err('ตัวเลือกไม่ถูกต้อง');
    const answers = { ...g.answers, [next.id]: c };
    await s.from('game_results').update({ answers }).eq('id', g.id);
    return Response.json({ correct: next.correct, isRight: c === next.correct });
  }
  if (b.action === 'finish') {
    if (qs.some((q) => !(q.id in g.answers))) return err('ยังตอบไม่ครบ', 409);
    const score = qs.filter((q) => g.answers[q.id] === q.correct).length;
    const now = new Date();
    await s.from('game_results').update({ score, total: qs.length, status: 'done', finished_at: now.toISOString(), play_ms: now - new Date(g.started_at) }).eq('id', g.id);
    return Response.json({ score, total: qs.length });
  }
  return err('unknown action');
}
