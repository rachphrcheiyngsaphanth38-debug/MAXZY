# MAXZY QUIZ 💜 — วิธีติดตั้งและเปิดให้เพื่อนเล่น

1. **Supabase**: supabase.com → New project → SQL Editor → วางไฟล์ `supabase/schema.sql` แล้ว Run (สร้างตาราง + RLS + คำถาม 15 ข้อ)
2. **คีย์**: Project Settings → API → คัดลอก `Project URL` และ `service_role key` (ห้ามใส่ใน NEXT_PUBLIC_ และห้ามแชร์)
3. **ENV**: ก๊อป `.env.example` เป็น `.env.local` ใส่ค่า 4 ตัว (ADMIN_PASSWORD = รหัสแอดมินของแม็กซ์, SESSION_SECRET = ข้อความสุ่มยาวๆ)
4. **ทดสอบในเครื่อง**: `npm install && npm run dev` → เปิด http://localhost:3000
5. **Deploy**: push ขึ้น GitHub → vercel.com → Add New Project → เลือก repo → ใส่ ENV 4 ตัวเดิมใน Environment Variables → Deploy
6. **URL สาธารณะ**: Vercel จะให้ลิงก์ `https://ชื่อโปรเจกต์.vercel.app` ส่งลิงก์นี้ให้เพื่อนได้เลย
7. **Admin**: ไปที่ `/admin` ใส่ ADMIN_PASSWORD (ไม่มีบัญชีแยก ใช้รหัสผ่านเดียว ตรวจสิทธิ์ที่ API ทุกครั้งด้วยคุกกี้เซ็นลายเซ็น)
8. **เช็คก่อนเปิดจริง**: เล่นจบ 1 รอบ → ดูอันดับ → เข้า /admin ลบผลทดสอบ/กดรีเซ็ต → แก้คำถามแล้วลองเล่นใหม่ → ปิด/เปิดเกม

ความปลอดภัย: ตารางทั้งหมดเปิด RLS และไม่มี policy จึงอ่าน/เขียนตรงจาก browser ไม่ได้ ทุกอย่างผ่าน API ฝั่งเซิร์ฟเวอร์ เฉลยไม่ถูกส่งไปกับคำถาม ส่งเฉพาะหลังตอบแต่ละข้อ และคะแนนคำนวณฝั่งเซิร์ฟเวอร์จากคำตอบที่บันทึกไว้
