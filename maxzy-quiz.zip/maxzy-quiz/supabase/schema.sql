create extension if not exists pgcrypto;
create table questions (id uuid primary key default gen_random_uuid(), position int not null, text text not null, options jsonb not null, correct int not null check (correct between 0 and 3));
create table players (id uuid primary key default gen_random_uuid(), name text not null, created_at timestamptz default now());
create table game_results (id uuid primary key default gen_random_uuid(), player_id uuid references players(id) on delete set null, player_name text not null, score int default 0, total int default 0, answers jsonb default '{}', status text default 'playing', started_at timestamptz default now(), finished_at timestamptz, play_ms bigint default 0);
create table admin_settings (key text primary key, value text);
-- RLS: เปิดและไม่มี policy = anon/authenticated อ่านเขียนตรงไม่ได้เลย; มีแต่ Service Role (ฝั่ง API) เท่านั้น
alter table questions enable row level security; alter table players enable row level security;
alter table game_results enable row level security; alter table admin_settings enable row level security;
revoke all on questions, players, game_results, admin_settings from anon, authenticated;
insert into admin_settings values ('game_open','true');
insert into questions (position,text,options,correct) values
(1,'แม็กซ์ชอบกินอะไรมากที่สุด?','["ต้มยำกุ้ง","แกงเขียวหวาน","กะเพราหมูกรอบ","ข้าวมันไก่"]',1),
(2,'เครื่องดื่มโปรดของแม็กซ์คืออะไร?','["ชาเขียว","โกโก้","ชาดำ","ชานมไข่มุก"]',2),
(3,'สีที่แม็กซ์ชอบคือสีอะไร?','["น้ำเงินกับขาว","แดงกับดำ","ม่วงกับชมพู","เขียวกับเหลือง"]',1),
(4,'เวลาว่างแม็กซ์ชอบทำอะไร?','["ออกไปเที่ยว","อ่านหนังสือ","นอนเล่นเกม","ออกกำลังกาย"]',2),
(5,'แม็กซ์ชอบคนแบบไหน?','["เงียบๆ โลกส่วนตัวสูง","นิสัยดี เป็นรุ่นน้องหรือเพื่อน ทะลึ่งๆ หน่อย","เรียบร้อย ไม่ค่อยพูด","สายปาร์ตี้ ชอบเที่ยว"]',1),
(6,'ถ้าให้อธิบายนิสัยตัวเอง แม็กซ์จะเลือกอะไร?','["เงียบ ขรึม เย็นชา","บ้า เบียว รักเดียว","เจ้าชู้ ขี้อ้อน ขี้งอน","สุขุม จริงจัง โลกส่วนตัวสูง"]',1),
(7,'แม็กซ์ชอบอะไรในตัวเองมากที่สุด?','["หน้าตาดี","เล่นเกมเก่ง","ให้คำปรึกษาคนอื่นได้ดี","มีเงินเยอะ"]',2),
(8,'อะไรทำให้แม็กซ์อารมณ์ดีได้ง่ายที่สุด?','["ได้เงิน","มีคนชวนคุย","ได้นอนทั้งวัน","ได้ออกไปเที่ยว"]',1),
(9,'ถ้าแม็กซ์มีเงิน 1 ล้านบาท จะทำอะไรเป็นอย่างแรก?','["ซื้อรถหรู","ซื้อบ้าน","เปย์เพื่อนๆ","เก็บเงินไว้ทั้งหมด"]',2),
(10,'แม็กซ์ชอบเที่ยวที่ไหนมากกว่ากัน?','["ภูเขา","ทะเล","น้ำตก","ต่างประเทศ"]',1),
(11,'สิ่งที่แม็กซ์กลัวที่สุดคืออะไร?','["งู","แมงมุม","คางคก","จิ้งจก"]',2),
(12,'ถ้าแม็กซ์อกหักจะทำอะไร?','["ออกไปปาร์ตี้","นอนฟังเพลง","โทรหาเพื่อน","หาแฟนใหม่ทันที"]',1),
(13,'แม็กซ์ชอบให้คนอื่นเรียกว่าอะไร?','["แม็กซ์จัง","แม็กซ์ซี่","พี่แม็กซ์","คุณชายแม็กซ์"]',1),
(14,'อะไรที่แม็กซ์ไม่ชอบที่สุด?','["คนพูดมาก","คนมาสาย","โดนบังคับตอนขี้เกียจ","คนไม่ตอบแชต"]',2),
(15,'สิ่งที่แม็กซ์ให้ความสำคัญที่สุดในความสัมพันธ์คืออะไร?','["หน้าตาและฐานะ","สนใจกันและกัน ไม่นอกใจ","ซื้อของให้กันบ่อยๆ","อยู่ด้วยกันตลอด 24 ชั่วโมง"]',1);
